#ifndef _MOD_ON_
#define _MOD_ON_
long long MOD;

long long pnorm(long long n);

long long inv(long long a, long long b);

long long padd(long long a, long long b);

long long psub(long long a, long long b);

long long pmul(long long a, long long b);

long long pdiv(long long a, long long b);
#endif