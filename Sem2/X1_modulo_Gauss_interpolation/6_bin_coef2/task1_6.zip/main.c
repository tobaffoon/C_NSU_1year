#include <stdio.h>

unsigned long long gcd(unsigned long long a, unsigned long long b){
    if(b == 0)
        return a;

    return gcd(b, a%b);
}

//return x from a*x+b*y = gcd(a,b)
unsigned long long gcd_ex(unsigned long long a, unsigned long long b){
    static unsigned long long x=0, x1=0, y1=0;

    if(b == 0){
        x1 = 1;
        y1 = 0;
        return x;
    }
    else{
        gcd_ex(b, a%b);
    }
    x = y1;

    y1 = x1 - (a/b) * y1;
    x1 = x;

    return x;
}

//calculates remainder of division by module of (number)!
int module_fac(int number, int module){
    unsigned long long   result = 1,
                remainder;

    while(number > 1){
        if((number/module) % 2 == 1) {
            result *= (module - 1);
            result %= module;
        }
        remainder = number % module;
        for(int i = 2; i <= remainder; i++){
            result *= i;
            result %= module;
        }
        number /= module;
    }

    return result;
}

int inverse_by_modulo(unsigned long long number, unsigned long long module){
    if(gcd(number,module) != 1)
        return -1;

    else
        return (gcd_ex(number, module) % module + module) % module;
}

int bin_coef(int n, int k, int module){
    if(k < 0 || k > n)
        return 0;

    unsigned long long       result = module_fac(n, module),
                            inverse_k = module_fac(k, module),
                            inverse_nk = module_fac((n-k), module),
                            inverse = inverse_k * inverse_nk;
    inverse = inverse_by_modulo(inverse, module);

    result *= inverse;
    result %= module;

    return result;
}


int main() {
    FILE    *fi = fopen("input.txt", "r"),
            *fo = fopen("output.txt", "w");

    int     module = 1000000007,
            tests,
            elements,
            k_comb;

    fscanf(fi, "%d", &tests);

    for (int i = 0; i < tests; ++i) {
        fscanf(fi, "%d%d", &elements, &k_comb);

        fprintf_s(fo, "%llu\n", bin_coef(elements, k_comb, module));
    }
    fclose(fi);
    fclose(fo);
    return 0;
}
